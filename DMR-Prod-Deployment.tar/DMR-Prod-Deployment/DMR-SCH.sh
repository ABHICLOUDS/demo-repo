#!/bin/bash
cd /home/mayordmr/DMR-deployment
ansible-playbook -vv ./DMR-SCH-QA.yml --check
