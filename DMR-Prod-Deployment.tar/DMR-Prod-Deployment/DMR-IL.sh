#!/bin/bash
cd /home/mayordmr/DMR-deployment
ansible-playbook -vv ./DMR-IL-QA.yml --check
