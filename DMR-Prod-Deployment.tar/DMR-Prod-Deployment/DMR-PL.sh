#!/bin/bash
cd /home/mayordmr/DMR-deployment
ansible-playbook -vv ./DMR-PL-QA.yml
